﻿using System.Windows.Forms;

namespace Neo.UI
{
    internal partial class DeveloperToolsForm : Form
    {
        public DeveloperToolsForm()
        {
            InitializeComponent();
            InitializeTxBuilder();
        }
    }
}
