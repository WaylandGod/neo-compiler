﻿namespace Neo.UI.Wrappers
{
    internal class IssueTransactionWrapper : TransactionWrapper
    {
    }
}
