﻿namespace Neo.UI.Wrappers
{
    internal class ContractTransactionWrapper : TransactionWrapper
    {
    }
}
